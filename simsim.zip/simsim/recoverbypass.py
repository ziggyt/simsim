import logging
from beamngpy import BeamNGpy
from beamngpy.sensors import RoadsSensor, Sensor
import time
import csv

def main():
    # Set up logging
    logging.basicConfig(level=logging.DEBUG)

    try:
        # Connect to the existing BeamNG.tech instance
        bng = BeamNGpy('localhost', 64256)
        bng.open(launch=False)




    except Exception as e:
        print("blabla")

    vehicles = bng.get_current_vehicles()
    player_vehicle = vehicles['ego_vehicle']
    player_vehicle.connect(bng)


    while True:
        input("press r + enter to recover vehicle")


        player_vehicle.recover()

        player_vehicle.



main()