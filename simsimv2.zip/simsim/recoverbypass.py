import logging
from beamngpy import BeamNGpy
from beamngpy.sensors import RoadsSensor, Sensor
import time
import csv

run_at_home = False
def main():
    # Set up logging
    bng_home = r'C:\Users\CAPsim\Documents\beamng'


    # Set up logging
    logging.basicConfig(level=logging.DEBUG)

    # Specify the path to your BeamNG.tech installation

    # beamng_home = r" # Path for running scenario at home
    try:
        # Connect to BeamNG.tech
        bng = BeamNGpy('localhost', 64256, home=bng_home,
                       user=r'C:\Users\CAPsim\Documents\beamng\BeamNG.tech.v0.31.2.0\tech\max')
        bng.open(launch=True)



    except Exception as e:
        print("blabla")


    print("BNG OPENED")




    try:

        vehicles = bng.get_current_vehicles()
        player_vehicle = vehicles['ego_vehicle']
        player_vehicle.connect(bng)


        player_vehicle.recover()

    except Exception as e:
        print(e)








main()