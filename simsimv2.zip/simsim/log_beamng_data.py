import logging
from beamngpy import BeamNGpy
from beamngpy.sensors import RoadsSensor, State
import time
import csv
from datetime import datetime


def main():
    logging.basicConfig(level=logging.DEBUG)

    try:
        bng = BeamNGpy('localhost', 64256)
        bng.open(launch=False)
        logging.info("Connected to existing BeamNG.tech instance")

        scenario = bng.scenario.get_current()
        player_vehicle = scenario.get_vehicle('ego_vehicle')


        roads_sensor = RoadsSensor('roads', bng, player_vehicle)

        start_datetime = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_filename = f'intoxeye_beamng_data_{start_datetime}.csv'

        with open(csv_filename, 'w', newline='') as csvfile:
            csv_writer = csv.writer(csvfile)
            csv_writer.writerow(['Timestamp', 'DistanceToLeft', 'DistanceToRight', 'DistanceToCenter', 'velocity', 'rotation', 'position'])

            while True:
                road_data = roads_sensor.poll()
                player_vehicle.poll_sensors()
                logging.debug(f"Road data: {road_data}")


                current_time = datetime.now().strftime("%H:%M:%S")
                if isinstance(road_data, dict) and 0.0 in road_data:
                    data = road_data[0.0]
                    dist_left = data.get('dist2Left', 'N/A')
                    dist_right = data.get('dist2Right', 'N/A')
                    dist_center = data.get('dist2CL', 'N/A')

                    speed = player_vehicle.sensors['state']['vel']
                    rotation = player_vehicle.sensors['state']['rotation']
                    position = player_vehicle.sensors['state']['pos']
                    csv_writer.writerow([current_time, dist_left, dist_right, dist_center, speed, rotation, position])
                else:
                    #logging.warning(f"Unexpected road data format: {road_data}")
                    csv_writer.writerow([current_time, 'N/A', 'N/A', 'N/A'])


                print(player_vehicle.sensors)

                time.sleep(0.25)

    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}", exc_info=True)


if __name__ == "__main__":
    main()
